import os
from datetime import date
from typing import Optional
import httpx
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

API_KEY = os.getenv("FOOTBALL_API_KEY", "").strip()
API_BASE = "https://v3.football.api-sports.io"
app = FastAPI(title="Football Intelligence AI API", version="0.3.0")

@app.get("/api/health")
def health():
    return {"ok": True, "provider": "API-Football", "provider_configured": bool(API_KEY)}

@app.get("/api/fixtures")
async def fixtures(match_date: date = Query(..., alias="date"), league: Optional[int] = None):
    if not API_KEY:
        raise HTTPException(status_code=503, detail="No football data API key configured. Set FOOTBALL_API_KEY on the server.")
    params = {"date": match_date.isoformat(), "timezone": "Africa/Lagos"}
    if league:
        params["league"] = league
    headers = {"x-apisports-key": API_KEY}
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            response = await client.get(f"{API_BASE}/fixtures", params=params, headers=headers)
        response.raise_for_status()
        payload = response.json()
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Football data provider request failed: {exc}")
    errors = payload.get("errors")
    if errors:
        raise HTTPException(status_code=502, detail={"provider_errors": errors})
    output = []
    for item in payload.get("response", []):
        fixture = item.get("fixture", {})
        teams = item.get("teams", {})
        league_data = item.get("league", {})
        output.append({
            "id": fixture.get("id"),
            "kickoff": fixture.get("date"),
            "status": (fixture.get("status") or {}).get("long"),
            "home": (teams.get("home") or {}).get("name"),
            "away": (teams.get("away") or {}).get("name"),
            "league": league_data.get("name"),
            "country": league_data.get("country"),
            "season": league_data.get("season"),
        })
    return output

app.mount("/", StaticFiles(directory="static", html=True), name="static")
