# Football Intelligence AI — v0.3 data-connected MVP

## What changed
- Responsive website/PWA interface for Android and desktop.
- Backend proxy for API-Football fixtures.
- Date and optional league filtering.
- API key stays on the server, not in browser JavaScript.
- Selecting a fixture fills the match form; the user must still supply expected goals until the data-derived model is implemented.
- Poisson probability engine, 1X2, BTTS, totals, likely scorelines, local saved history.

## Data provider
This build is wired to API-Football v3. Its current public pricing page advertises a $0 plan with 100 requests/day and access to multiple endpoint categories, while noting free-plan season limitations. Coverage varies by competition and endpoint; check the provider dashboard before relying on a league. Sources:
- API-Football pricing: https://www.api-football.com/
- API-Football documentation: https://www.api-football.com/documentation-v3

The app is not connected until you create an API key and configure it on the backend.

## Run
Requires Python 3.10+.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

Copy `.env.example` to `.env`, then set `FOOTBALL_API_KEY`. Load environment variables before running. One simple option:
```bash
pip install python-dotenv
```
Then add `from dotenv import load_dotenv; load_dotenv()` near the top of `main.py`, or export the variable in your terminal.

Linux/macOS:
```bash
export FOOTBALL_API_KEY="your_private_key"
uvicorn main:app --host 0.0.0.0 --port 8000
```
Windows PowerShell:
```powershell
$env:FOOTBALL_API_KEY="your_private_key"
uvicorn main:app --host 0.0.0.0 --port 8000
```
Open http://localhost:8000.

## Android
Deploy the app and backend to an HTTPS host, then open the website in Chrome on Android and choose Install app / Add to Home screen. This is a PWA install, not a native APK. Do not expose the provider key in static hosting configuration or frontend source.

## Current limitations
- Fixture data is live only after a valid API key is configured.
- This version does not yet fetch team statistics, lineups, injuries, odds, expert analysis/news or historical data.
- It does not derive expected goals from team data yet; expected goals are manually entered.
- Poisson is an independent-goals baseline. Dixon–Coles, Elo, Monte Carlo, machine learning, backtesting and calibrated probabilities are future milestones.
- API data coverage and rate limits depend on the provider plan and competition.

## Next steps
1. Configure and verify the API key.
2. Add team-statistics and historical-results ingestion.
3. Estimate attack/defence strengths and expected goals from data.
4. Add Dixon–Coles correction, Elo and Monte Carlo ensemble.
5. Add cited, timestamped expert/news summaries from permitted sources.
6. Backtest chronologically using Brier score, log loss and calibration.
